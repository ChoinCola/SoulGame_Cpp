#include <iostream> 
#include <cstdio>

int main()
{
    std::cout << "Hello, c++!!" << std::endl;

    std::cout << "Hello, c++!!" << "\n";

    int x = 10;
    int y = 20;

    std::cout << "x = " << x << " " << "y = " << y << std::endl;
    std::cout << "x + y = " << x + y << std::endl;

    return 0;
}