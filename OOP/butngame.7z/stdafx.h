#pragma once

#include <iostream>
#include <random>
#include <chrono>
#include <conio.h>
#include <Windows.h>

#include "timer.h"
#include "Math.h"

using namespace std;
